---
course: 江协科技 STM32入门教程-2023版
type: 课程总索引
source: https://www.bilibili.com/video/BV1th411z7sn
tags:
  - STM32
  - 江协科技
  - 索引
  - MOC
status: draft
updated: 2026-09-26
---

# 江协科技 STM32 入门教程 · 课程总索引

> [!info] 这是整套课程的入口
> 课程共 15 章、50 个分 P。**一个章节目录装一章**，目录里第一张是本章索引页，其余按集编号往下细分。
> 课程主页：<https://www.bilibili.com/video/BV1th411z7sn>

## 目录约定

```text
笔记/STM32/江协科技/
├── 江协STM32 课程总索引.md          ← 你在这里
├── 01 STM32简介/
├── 02 开发环境搭建/
├── 03 GPIO/
├── 04 OLED/
├── 05 EXTI外部中断/
├── 06 TIM定时器/                    ← 一个章节目录
│   ├── 江协STM32 06 TIM定时器（章索引）.md   ← 章索引，永远排在最前
│   ├── 江协STM32 06-1 TIM定时中断.md
│   └── ...
└── _旧稿归档/                       ← 早期待整理版本，随时可删
```

- **文件名统一带 `江协STM32 ` 前缀**：Obsidian 的 `[[双链]]` 只认文件名不认路径，带前缀可以保证全库不重名，笔记搬家也不会断链。
- **章节目录名用 `章节号 空格 章节名`**：和视频目录的顺序一致，文件列表天然按集数排好。

## 章节目录

| 章 | 章节 | 集数 | 分 P | 状态 |
| --- | --- | --- | --- | --- |
| 01 | [[江协STM32 01 STM32简介（章索引）\|STM32简介]] | 1-1 ~ 1-2 | P1 ~ P2 | 已完成 ✅ |
| 02 | [[江协STM32 02 开发环境搭建（章索引）\|开发环境搭建]] | 2-1 ~ 2-2 | P3 ~ P4 | 已完成 ✅ |
| 03 | [[江协STM32 03 GPIO（章索引）\|GPIO]] | 3-1 ~ 3-4 | P5 ~ P8 | 已完成 ✅ |
| 04 | [[江协STM32 04 OLED（章索引）\|OLED]] | 4-1 ~ 4-2 | P9 ~ P10 | 已完成 ✅ |
| 05 | [[江协STM32 05 EXTI外部中断（章索引）\|EXTI 外部中断]] | 5-1 ~ 5-2 | P11 ~ P12 | 已完成 ✅ |
| 06 | [[江协STM32 06 TIM定时器（章索引）\|TIM 定时器]] | 6-1 ~ 6-8 | P13 ~ P20 | 已完成 ✅ |
| 07 | [[江协STM32 07 ADC（章索引）\|ADC 模数转换器]] | 7-1 ~ 7-2 | P21 ~ P22 | 已完成 ✅ |
| 08 | [[江协STM32 08 DMA（章索引）\|DMA 直接存储器存取]] | 8-1 ~ 8-2 | P23 ~ P24 | 已完成 ✅ |
| 09 | [[江协STM32 09 USART串口（章索引）\|USART 串口]] | 9-1 ~ 9-5 | P25 ~ P29 | 已完成 ✅（9-6 未做） |
| 10 | [[江协STM32 10 I2C（章索引）\|I2C 通信 / MPU6050]] | 10-1 ~ 10-5 | P31 ~ P35 | 已完成 ✅ |
| 11 | [[江协STM32 11 SPI（章索引）\|SPI 通信 / W25Q64]] | 11-1 ~ 11-5 | P36 ~ P40 | 已完成 ✅ |
| 12 | Unix 时间戳 / BKP / RTC | 12-1 ~ 12-3 | P41 ~ P43 | 未开始 |
| 13 | PWR 电源控制 | 13-1 ~ 13-2 | P44 ~ P45 | 未开始 |
| 14 | WDG 看门狗 | 14-1 ~ 14-2 | P46 ~ P47 | 未开始 |
| 15 | FLASH 闪存 | 15-1 ~ 15-2 | P48 ~ P49 | 未开始 |

## 01 STM32简介

入口：[[江协STM32 01 STM32简介（章索引）]]

| 集 | 标题 | 页码 | 笔记 |
| --- | --- | --- | --- |
| 1-1 | 课程简介 | [P1](https://www.bilibili.com/video/BV1th411z7sn?p=1) | [[江协STM32 01-1 课程简介]] |
| 1-2 | STM32简介 | [P2](https://www.bilibili.com/video/BV1th411z7sn?p=2) | [[江协STM32 01-2 STM32简介]] |

## 02 开发环境搭建

入口：[[江协STM32 02 开发环境搭建（章索引）]]

| 集 | 标题 | 页码 | 笔记 |
| --- | --- | --- | --- |
| 2-1 | 软件安装 | [P3](https://www.bilibili.com/video/BV1th411z7sn?p=3) | [[江协STM32 02-1 软件安装]] |
| 2-2 | 新建工程 | [P4](https://www.bilibili.com/video/BV1th411z7sn?p=4) | [[江协STM32 02-2 新建工程]] |

## 03 GPIO

入口：[[江协STM32 03 GPIO（章索引）]]

| 集 | 标题 | 页码 | 笔记 |
| --- | --- | --- | --- |
| 3-1 | GPIO输出 | [P5](https://www.bilibili.com/video/BV1th411z7sn?p=5) | [[江协STM32 03-1 GPIO输出]] |
| 3-2 | LED闪烁&LED流水灯&蜂鸣器 | [P6](https://www.bilibili.com/video/BV1th411z7sn?p=6) | [[江协STM32 03-2 LED闪烁与流水灯与蜂鸣器]] |
| 3-3 | GPIO输入 | [P7](https://www.bilibili.com/video/BV1th411z7sn?p=7) | [[江协STM32 03-3 GPIO输入]] |
| 3-4 | 按键控制LED&光敏传感器控制蜂鸣器 | [P8](https://www.bilibili.com/video/BV1th411z7sn?p=8) | [[江协STM32 03-4 按键控制LED与光敏传感器]] |

## 04 OLED

入口：[[江协STM32 04 OLED（章索引）]]

| 集 | 标题 | 页码 | 笔记 |
| --- | --- | --- | --- |
| 4-1 | OLED调试工具 | [P9](https://www.bilibili.com/video/BV1th411z7sn?p=9) | [[江协STM32 04-1 OLED调试工具]] |
| 4-2 | OLED显示屏 | [P10](https://www.bilibili.com/video/BV1th411z7sn?p=10) | [[江协STM32 04-2 OLED显示屏]] |

## 05 EXTI 外部中断

入口：[[江协STM32 05 EXTI外部中断（章索引）]]

| 集 | 标题 | 页码 | 笔记 |
| --- | --- | --- | --- |
| 5-1 | EXTI外部中断 | [P11](https://www.bilibili.com/video/BV1th411z7sn?p=11) | [[江协STM32 05-1 EXTI外部中断]] |
| 5-2 | 对射式红外传感器计次&旋转编码器计次 | [P12](https://www.bilibili.com/video/BV1th411z7sn?p=12) | [[江协STM32 05-2 红外传感器计次与旋转编码器计次]] |

## 06 TIM定时器

入口：[[江协STM32 06 TIM定时器（章索引）]]

| 集 | 标题 | 页码 | 笔记 |
| --- | --- | --- | --- |
| 6-1 | TIM定时中断 | [P13](https://www.bilibili.com/video/BV1th411z7sn?p=13) | [[江协STM32 06-1 TIM定时中断]] |
| 6-2 | 定时器定时中断&定时器外部时钟 | [P14](https://www.bilibili.com/video/BV1th411z7sn?p=14) | [[江协STM32 06-2 定时器外部时钟]] |
| 6-3 | TIM输出比较 | [P15](https://www.bilibili.com/video/BV1th411z7sn?p=15) | [[江协STM32 06-3 TIM输出比较]] |
| 6-4 | PWM驱动LED呼吸灯&舵机&直流电机 | [P16](https://www.bilibili.com/video/BV1th411z7sn?p=16) | [[江协STM32 06-4 PWM 应用]] |
| 6-5 | TIM输入捕获 | [P17](https://www.bilibili.com/video/BV1th411z7sn?p=17) | [[江协STM32 06-5 TIM输入捕获]] |
| 6-6 | 输入捕获测频率&PWMI测频率占空比 | [P18](https://www.bilibili.com/video/BV1th411z7sn?p=18) | [[江协STM32 06-6 输入捕获测频率与占空比]] |
| 6-7 | TIM编码器接口 | [P19](https://www.bilibili.com/video/BV1th411z7sn?p=19) | [[江协STM32 06-7 TIM编码器接口]] |
| 6-8 | 编码器接口测速 | [P20](https://www.bilibili.com/video/BV1th411z7sn?p=20) | [[江协STM32 06-8 编码器接口测速]] |

## 07 ADC

入口：[[江协STM32 07 ADC（章索引）]]

| 集 | 标题 | 页码 | 笔记 |
| --- | --- | --- | --- |
| 7-1 | ADC模数转换器 | [P21](https://www.bilibili.com/video/BV1th411z7sn?p=21) | [[江协STM32 07-1 ADC模数转换器]] |
| 7-2 | AD单通道&AD多通道 | [P22](https://www.bilibili.com/video/BV1th411z7sn?p=22) | [[江协STM32 07-2 AD单通道与AD多通道]] |

## 08 DMA

入口：[[江协STM32 08 DMA（章索引）]]

| 集 | 标题 | 页码 | 笔记 |
| --- | --- | --- | --- |
| 8-1 | DMA直接存储器存取 | [P23](https://www.bilibili.com/video/BV1th411z7sn?p=23) | [[江协STM32 08-1 DMA直接存储器存取]] |
| 8-2 | DMA数据转运&DMA+AD多通道 | [P24](https://www.bilibili.com/video/BV1th411z7sn?p=24) | [[江协STM32 08-2 DMA数据转运与DMA+AD多通道]] |

## 09 USART 串口

入口：[[江协STM32 09 USART串口（章索引）]]

| 集 | 标题 | 页码 | 笔记 |
| --- | --- | --- | --- |
| 9-1 | USART串口协议 | [P25](https://www.bilibili.com/video/BV1th411z7sn?p=25) | [[江协STM32 09-1 USART串口协议]] |
| 9-2 | USART串口外设 | [P26](https://www.bilibili.com/video/BV1th411z7sn?p=26) | [[江协STM32 09-2 USART串口外设]] |
| 9-3 | 串口发送&串口发送+接收 | [P27](https://www.bilibili.com/video/BV1th411z7sn?p=27) | [[江协STM32 09-3 串口发送与串口发送接收]] |
| 9-4 | USART串口数据包 | [P28](https://www.bilibili.com/video/BV1th411z7sn?p=28) | [[江协STM32 09-4 USART串口数据包]] |
| 9-5 | 串口收发HEX数据包&串口收发文本数据包 | [P29](https://www.bilibili.com/video/BV1th411z7sn?p=29) | [[江协STM32 09-5 串口收发HEX数据包与文本数据包]] |
| 9-6 | FlyMcu串口下载&STLINK Utility | [P30](https://www.bilibili.com/video/BV1th411z7sn?p=30) | 本次未做 |

## 10 I2C

入口：[[江协STM32 10 I2C（章索引）]]

| 集 | 标题 | 页码 | 笔记 |
| --- | --- | --- | --- |
| 10-1 | I2C通信协议 | [P31](https://www.bilibili.com/video/BV1th411z7sn?p=31) | [[江协STM32 10-1 I2C通信协议]] |
| 10-2 | MPU6050简介 | [P32](https://www.bilibili.com/video/BV1th411z7sn?p=32) | [[江协STM32 10-2 MPU6050简介]] |
| 10-3 | 软件I2C读写MPU6050 | [P33](https://www.bilibili.com/video/BV1th411z7sn?p=33) | [[江协STM32 10-3 软件I2C读写MPU6050]] |
| 10-4 | I2C通信外设 | [P34](https://www.bilibili.com/video/BV1th411z7sn?p=34) | [[江协STM32 10-4 I2C通信外设]] |
| 10-5 | 硬件I2C读写MPU6050 | [P35](https://www.bilibili.com/video/BV1th411z7sn?p=35) | [[江协STM32 10-5 硬件I2C读写MPU6050]] |

## 11 SPI

入口：[[江协STM32 11 SPI（章索引）]]

| 集 | 标题 | 页码 | 笔记 |
| --- | --- | --- | --- |
| 11-1 | SPI通信协议 | [P36](https://www.bilibili.com/video/BV1th411z7sn?p=36) | [[江协STM32 11-1 SPI通信协议]] |
| 11-2 | W25Q64简介 | [P37](https://www.bilibili.com/video/BV1th411z7sn?p=37) | [[江协STM32 11-2 W25Q64简介]] |
| 11-3 | 软件SPI读写W25Q64 | [P38](https://www.bilibili.com/video/BV1th411z7sn?p=38) | [[江协STM32 11-3 软件SPI读写W25Q64]] |
| 11-4 | SPI通信外设 | [P39](https://www.bilibili.com/video/BV1th411z7sn?p=39) | [[江协STM32 11-4 SPI通信外设]] |
| 11-5 | 硬件SPI读写W25Q64 | [P40](https://www.bilibili.com/video/BV1th411z7sn?p=40) | [[江协STM32 11-5 硬件SPI读写W25Q64]] |

## 学习路线

```text
芯片与工具（1、2章）→ GPIO（3章）→ OLED 调试（4章）
     → 中断与 EXTI（5章）→ 定时器（6章）→ ADC/DMA（7、8章）
     → 串口（9章）→ I2C（10章）→ SPI（11章）→ RTC/电源/看门狗/FLASH（12~15章）
```

几个关键衔接点：

- **第 3 章是第一个能动手的章节**，八种 GPIO 模式是后面所有外设的基础。
- **第 4 章的 OLED 是全书最重要的调试手段**——第 5 章之后每一集的实验几乎都靠它显示变量。
- **第 5 章是第 6 章的前置**：NVIC、中断优先级分组、中断服务函数这几件事在 5-1 就讲过了，6-1 直接用。
- **5-2 与 6-7 是同一个问题的两种解法**：5-2 用 EXTI 手动判方向数编码器，6-7 改用定时器编码器接口硬件自动完成。两篇对照着看，能体会"该交给硬件的就交给硬件"。
- **第 6 章是全课程最重的一章**：8 集、约 5 小时，也是后面电机控制、传感器采集的地基。
- **第 7 章 ADC 与第 8 章 DMA 是一对**：7-2 多通道 AD 要手动切换通道，8-2 用 DMA 自动搬运。两篇连起来看才完整。
- **第 6 章的输出比较是第 10、11 章的伏笔**：软件 I2C 要开漏输出、软件 SPI 要推挽输出，这两种 GPIO 模式在 3-1 就讲过，这里才用到实处。
- **第 10、11 章都是「先协议 → 再外设 → 再硬件实现」的三段式**：10-1/10-4 讲 I2C 协议与硬件外设，10-3/10-5 是软件版与硬件版的同一件事；11 章同构。**软件版和硬件版的逐函数对照表是这两章最值钱的部分。**
- **9-6 只讲下载工具**（FlyMcu / STLINK Utility），没有新外设知识，本次按你的要求跳过。

> [!tip] 怎么用这套笔记
> 每篇分集笔记的结构是固定的：**开篇一句话点明这集解决的问题 → 原理与电路 → 参数表 → 完整代码 → 易错点清单 → 自测题（带折叠答案）→ 待核对 → 核对记录**。
> 复习时只看「易错点」和「自测」两节就够；要写代码时直接翻「完整代码」节。
>
> 最后的**「核对记录」**是一张表，逐条写明这一页的每个技术事实是拿哪份**官方材料**核对的、结论是「一致」还是「已修正」。想确认某条可不可信，看这张表。

## 相关

- 课程主页：<https://www.bilibili.com/video/BV1th411z7sn>
- **官方配套资料（本机）**：`C:\Users\陈杰裕\Desktop\资料\STM32入门教程资料\` —— 程序源码（有注释版）、40 张接线图、课件 PPT、参考手册、固件库 V3.5.0
- ⚠️ 第三方源码镜像 <https://gitee.com/KSweb/stm32f1doc> **与课程 2023 版官方源码不是同一版本**（实例：OLED 驱动引脚，镜像是 `PB6/PB7`，官方是 `PB8/PB9`）。**不要拿它核对参数。**

> [!note] 出处说明与核对口径
> **章节划分、分 P 编号与视频时长**：来自 B 站官方分 P 接口 `api.bilibili.com/x/player/pagelist?bvid=BV1th411z7sn`，已逐个核对。
>
> **笔记里的技术事实**（引脚、寄存器、库函数、参数、公式、代码）：已逐条对照**本机课程官方资料包**核对 —— 程序源码（`STM32Project-有注释版`，老师亲手写、带中文注释）、官方接线图（40 张，每集一张）、课件 PPT（207 页）、`STM32F103C8T6引脚定义.xlsx`、ST 标准外设库 V3.5.0 与官方参考手册。每篇末尾的「核对记录」表列出了逐条结论。
>
> **仍未核实的**：老师的**口头原话**与**视频画面细节**。这类信息不在源码、接线图、课件文本里，笔记无法保证「与老师原话逐字相同」，相关条目都留在各篇的「待核对」中并写明「官方资料中未见」。
>
> 一句话：**技术内容可追溯到官方原始材料；讲课原话以视频为准。**
